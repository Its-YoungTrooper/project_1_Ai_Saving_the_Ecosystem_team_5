
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import roc_auc_score, f1_score
from sklearn.utils.class_weight import compute_class_weight
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam
import joblib
import datetime
from datetime import datetime as dt
from sklearn.metrics import accuracy_score, precision_score, recall_score

app = Flask(__name__, static_folder='static')
CORS(app)

models = {}
scaler = None
df = None


def load_and_preprocess_data(filepath):
    global df
    df = pd.read_csv(filepath)
    df['MapDate'] = pd.to_datetime(df['MapDate'])
    df['drought_severity'] = (
        (0.05 * df['D0'] + 0.15 * df['D1'] + 0.3 * df['D2'] + 0.5 * df['D3'] + 0.8 * df['D4']) / 100
    )
    df['severe_drought'] = (df['drought_severity'] > 0.15).astype(int)
    df['day_of_year'] = df['MapDate'].dt.dayofyear
    df['month'] = df['MapDate'].dt.month
    return df


def calculate_class_weight(y):
    classes = np.unique(y)
    weights = compute_class_weight('balanced', classes=classes, y=y)
    return weights[1] / weights[0]


def build_lstm(input_shape):
    model = Sequential([
        Reshape((1, input_shape), input_shape=(input_shape,)),
        LSTM(64),
        Dropout(0.3),
        Dense(32, activation='relu'),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer=Adam(0.0005), loss='binary_crossentropy', metrics=['accuracy'])
    return model


def train_models():
    global models, scaler, df
    
    
    features = df[['D0', 'D1', 'D2', 'D3', 'D4', 'day_of_year', 'month']]
    target = df['severe_drought']
    
    
    X_train, X_test, y_train, y_test = train_test_split(
        features, target, test_size=0.2, stratify=target, random_state=42
    )
    
    
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    
    weight = calculate_class_weight(target)

    
    models = {
        'SVM': SVC(
            probability=True,
            kernel='rbf',
            class_weight='balanced',
            C=1.0,
            gamma='scale'
        )
    }

    
    model_metrics = {}
    for name, model in models.items():
        
        model.fit(X_train_scaled, y_train)
        
        
        y_pred = model.predict(X_test_scaled)
        y_proba = model.predict_proba(X_test_scaled)[:, 1] if hasattr(model, "predict_proba") else [0]*len(y_test)
        
        
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        roc_auc = roc_auc_score(y_test, y_proba) if hasattr(model, "predict_proba") else None
        
        
        model_metrics[name] = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'roc_auc': roc_auc
        }
    
    
    print("\nModels and their accuracy:")
    print("{:<20} {:<10} {:<10} {:<10} {:<10} {:<10}".format(
        'Model', 'Accuracy', 'Precision', 'Recall', 'F1', 'ROC AUC'))
    for name, metrics in model_metrics.items():
        print("{:<20} {:<10.4f} {:<10.4f} {:<10.4f} {:<10.4f} {:<10.4f}".format(
            name,
            metrics['accuracy'],
            metrics['precision'],
            metrics['recall'],
            metrics['f1_score'],
            metrics['roc_auc'] if metrics['roc_auc'] is not None else 0
        ))
    
    
    joblib.dump(models, 'drought_models.pkl')
    joblib.dump(scaler, 'drought_scaler.pkl')
    joblib.dump(model_metrics, 'model_metrics.pkl')
    
    return models, scaler, model_metrics


@app.route('/')
def index():
    return send_from_directory('static', 'index.html')


@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        fields = ['D0', 'D1', 'D2', 'D3', 'D4', 'day_of_year', 'month']
        features = pd.DataFrame([[data[f] for f in fields]], columns=fields)
        scaled = scaler.transform(features)

        results = {}
        probabilities = {}
        
        for name, model in models.items():
            if name == 'LSTM':
                proba = float(model.predict(scaled)[0][0])
                pred = int(proba > 0.5)
            else:
                proba = float(model.predict_proba(scaled)[0][1])
                pred = int(model.predict(scaled)[0])
            
            results[name] = pred
            probabilities[name] = proba

        
        model_metrics = joblib.load('model_metrics.pkl')
        total_f1 = sum(m['f1_score'] for m in model_metrics.values())
        
        weighted_proba = 0
        for name, proba in probabilities.items():
            weight = model_metrics.get(name, {}).get('f1_score', 1) / total_f1
            weighted_proba += proba * weight

        consensus = int(weighted_proba > 0.5)

        return jsonify({
            'predictions': results,
            'probabilities': probabilities,
            'weighted_probability': weighted_proba,
            'consensus_prediction': consensus,
            'severity_level': consensus,
            'severity_score': weighted_proba,
            'status': 'success'
        })

    except Exception as e:
        return jsonify({'error': str(e), 'status': 'error'}), 500


@app.route('/stats')
def get_stats():
    global df
    stats = {
        'total_records': len(df),
        'average_severity': df['drought_severity'].mean(),
        'severe_drought_percent': df['severe_drought'].mean() * 100
    }
    return jsonify({'statistics': stats, 'status': 'success'})


def initialize():
    global models, scaler
    load_and_preprocess_data('dm_export_18000802_20250802 (1).csv')
    train_models()
    return True


if __name__ == '__main__':
    if initialize():
        app.run(host='0.0.0.0', port=5000, debug=True)
    else:
        print("Initialization failed.")
